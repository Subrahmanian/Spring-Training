Data JPA:  It offers a consistent way to talk to database using Spring

Steps:

1.  Add the dependency
2.  Write datasource properties in application.properties file
3.  Annotate Entity class with JPA annotations.
4.  Create an interface and extend it from JPA Repository
5.  We don't need any implementation class for repository
