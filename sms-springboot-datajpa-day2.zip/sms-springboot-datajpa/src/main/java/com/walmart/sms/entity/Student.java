package com.walmart.sms.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

//Each Java class by default extends object.
//Denotes that this is a JPA entity.
@Entity
@Table(name="tbl_student")
public class Student extends Object{

	
	//Instance variables
	//Denotes that this field is a primary key in the table.
	@Id
	private int rollNo;
	
	@Column(name="st_name",unique = true, nullable=false)
	private String name;
	
	@Column(name="st_marks")
	private float marks;
	
	public Student() {
		super(); //Invoke No-args constructor of Super class.  
				//Each Java class is a sub-class of Object.
	}
	public Student(int rollNo, String name, float marks) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.marks = marks;
	}
	
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getMarks() {
		return marks;
	}
	public void setMarks(float marks) {
		this.marks = marks;
	}
	
	
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", marks=" + marks + "]";
	}
	
		
	
}
