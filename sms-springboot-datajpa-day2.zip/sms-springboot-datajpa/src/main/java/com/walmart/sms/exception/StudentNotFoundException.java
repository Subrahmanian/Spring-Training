package com.walmart.sms.exception;

public class StudentNotFoundException extends Exception{
	
	
	
	

}
