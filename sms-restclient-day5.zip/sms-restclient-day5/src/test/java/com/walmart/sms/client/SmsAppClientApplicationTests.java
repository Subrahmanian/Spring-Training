package com.walmart.sms.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmsAppClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
