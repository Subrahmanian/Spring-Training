package com.walmart.sms.client;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestTemplate;

import com.walmart.sms.client.dto.Student;

@SpringBootApplication
public class SmsAppClientApplication {	
	
	//RestClient was introduced after SPring 6
	//Though usage of RT is valid till today
	//Any new development should be done using RC
	//As per SPring Team Rest Template might get deprecated 
	
	@Value("${spring.sms.baseurl}")
	private String baseUrl;
	
	@Bean
	public RestClient getRestClient() {
		return RestClient.create(baseUrl); 
	}
	
	@Bean
	public StudentRestClient restClient() {
		StudentRestClient studentClient = new StudentRestClient();
		return studentClient;
	}
	
	public static void main(String[] args) {
		ConfigurableApplicationContext container = SpringApplication.run(SmsAppClientApplication.class, args);
		StudentRestClient restClient = container.getBean(StudentRestClient.class);
		List<Student> clientObject = restClient.getAllStudents();
		System.out.println(clientObject);
		//Student clientObject = restClient.getStudentById(2);
		//System.out.println(clientObject.getMarks()+"\n"+clientObject.getName()+"\n"+clientObject.getRollNo());;
		
		//List nameDetails = rt.getForObject(baseUrl+"/student", List.class);
		
////			System.out.println(name.getName()+"\t"+name.getMarks()+"\t"+name.getRollNo());
//	System.out.println(nameDetails);	
//		Student s = new Student();
//		s.setMarks(100);
//		s.setName("Client");
//		s.setRollNo(100);
//		Student response = rt.postForObject(baseUrl+"/student", s,Student.class);
//		System.out.println(response);
		
	
		
	}
	
	

}
