package com.walmart.sms.client;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestTemplate;

import com.walmart.sms.client.dto.Student;

public class StudentRestClient {
	
	@Autowired
	private RestClient rc;
	
	
	public Student getStudentById(int id) {
		 String url = "student/"+id;
		 
		 
		 ResponseEntity<Student> responseEntity = rc.get()
				 								  .uri(url)
				 								  .retrieve()
				 								  .toEntity(Student.class);
		 if(responseEntity.getStatusCode() == HttpStatus.OK) {
			 return responseEntity.getBody();
		 }
		 else {
			 System.out.println("Entry not found");
			 return null;
		 }			 
	}
	
	public Student createStudent() {
		Student s = new Student();
		s.setMarks(100);
		s.setName("Subbu");
		s.setRollNo(100);		
		try{
			ResponseEntity<Student> entity = rc.post()
					  .uri("/student")
					  .body(s)
					  .retrieve()
					  .toEntity(Student.class);
			if(entity.getStatusCode() == HttpStatus.CREATED) {
				 return entity.getBody();
			 }
			else{System.out.println("Failed to create student");
			}
		}
		catch(Exception e) {
			System.out.println("Exception in creating student");
			return null;
		}
		return s;
	}
	
	public List<Student> getAllStudents() {
		return rc.get()
		.uri("/student")
		.retrieve()
		.toEntity(new ParameterizedTypeReference<List<Student>>() {})
		.getBody();
		 
	
	}
	
}
