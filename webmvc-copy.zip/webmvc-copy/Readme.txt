REST : Representational State Transfer

1.  An architectural style if applied to web services, it becomes REST web service.
2.  Following are important guidelines for REST

--> URI must be resource based(verbs should not be written in URI)
--> Appropriate use of HTTP method 
--> Appropriate usage of HTTP status codes
--> Important HTTP status codes:

Status Code |  Explanation
200 | Success
201 | Created
204 | No-Content
404 | Not Found
401 | Unauthorized
403 | Forbidden
405 | Method not supported
500 | Internal Server Error


--> Its the responsibility of a backend developer to return appropriate status codes.
--> To do so, in Spring we use ResponseEntity class.
--> 