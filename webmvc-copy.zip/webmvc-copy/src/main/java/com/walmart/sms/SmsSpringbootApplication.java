package com.walmart.sms;

import java.util.Scanner;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.walmart.sms.entity.Student;
import com.walmart.sms.exception.StudentNotFoundException;
import com.walmart.sms.service.StudentService;

@SpringBootApplication
//Its a combo of @ComponentScan, @Configuration, @EnableAutoConfiguration
public class SmsSpringbootApplication {

	public static void main(String[] args) {
		//Call to run method returns and references spring container
		ConfigurableApplicationContext container = SpringApplication.run(SmsSpringbootApplication.class, args);
		Student s;
		Student s1;
		Student s2;
		Student s3;
		s=new Student(1,"Subbu",95.5f);
		s=new Student(2,"Dexter",93.5f);//Object creation for student class
		StudentService service = container.getBean(StudentService.class);
		//service.register(s);
		System.out.println("Enter the option");
		Scanner sc = new Scanner(System.in);
		int n = 0;
		do {
			System.out.println("Enter the option 1 to register a user");
			System.out.println("Enter the option 2 to search for all users");

			System.out.println("Enter the option 3 to delete user");
			System.out.println("Enter the option 4 to search for individual user");
			System.out.println("Enter the option 5 to update marks for all users");
			System.out.println("Enter the option 6 to find student by name:");

			n=sc.nextInt();
			switch(n) {
			case 1:

				s1=new Student(1,"Subbu",95.5f);
				s2=new Student(2,"Dexter",93.5f);
				s3=new Student(3,"Jan",90.0f);
				service.register(s1);
				service.register(s2);
				service.register(s3);
				System.out.println("Student registered successfully");
				break;
			
			case 2: 

				System.out.println(service.searchAll());
				System.out.println("List of all students");
				break;
				
			case 3:
				System.out.println("Enter the ID to be deleted");
				int rollNo=sc.nextInt();
				service.deleteStudent(rollNo);
				
			case 4:
				System.out.println(service.searchAll());
				System.out.println("Enter the ID to be searched");
				int rollNbr = sc.nextInt();
				try {
					System.out.println(service.searchStudent(rollNbr));
				} catch (StudentNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
				
			case 5:
				System.out.println("Enter the roll nbr");
				int roll = sc.nextInt();
				System.out.println("Enter the marks to be updated");
				Float marks = sc.nextFloat();
				service.updateMarks(roll,marks);
				break;
				
				
			case 6:
				System.out.println("Enter the student name");
				String name = sc.next();
				Student foundStudent = service.findStudentByName(name);
				System.out.println(foundStudent);
				break;
				
			case -1:
				break;
			
			
			}
			} while(n!=-1);
		//System.out.println(service.searchAll());
	}
}
