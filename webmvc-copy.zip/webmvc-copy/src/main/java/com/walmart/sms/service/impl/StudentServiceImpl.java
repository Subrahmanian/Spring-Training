package com.walmart.sms.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.walmart.sms.entity.Student;
import com.walmart.sms.exception.StudentNotFoundException;
import com.walmart.sms.repository.StudentRepository;
import com.walmart.sms.service.StudentService;

@Service
@Repository
//Each service class must be annotated with @Service, to register it as a spring bean in a spring container.
public class StudentServiceImpl implements StudentService{

	//@Autowired //Its used to inject dependency(DI)
	private StudentRepository repo;
		
	@Autowired
	public StudentServiceImpl(StudentRepository repo) {
		super();		
		this.repo=repo;
		//repo=new StudentRepositoryImpl();//tight coupling
		//repo= new StudentJPARepositoryImpl();
	}
	

	//@Autowired
	public void setRepo(StudentRepository repo) {
		this.repo = repo;
		System.out.println("In Setter injection");
	}



	@Override
	public Student register(Student s) {
		// TODO Auto-generated method stub
		System.out.println("Student Registered");
		return repo.save(s); //Invoking save method of repository to insert the record in database.
	}

	@Override
	public List<Student> searchAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}


	@Override
	public int deleteStudent(int rollNo) {
		// TODO Auto-generated method stub
		
		repo.deleteById(rollNo);
		return rollNo;
	}


	@Override
	public Student searchStudent(int rollNo) throws StudentNotFoundException {
		// TODO Auto-generated method stub
		Optional<Student> o = this.repo.findById(rollNo);
		if(o.isPresent()) {
			return o.get();
		}
		else {
			throw new StudentNotFoundException();
		}
	}


	@Override
	 public void updateMarks(int rollNbr, float marks) {
Student foundStudent  = this.repo.findById(rollNbr).get();
foundStudent.setMarks(marks);
repo.save(foundStudent);

}


	@Override
	public Student findStudentByName(String name) {
		// TODO Auto-generated method stub
		return this.repo.findByName(name);
	}
	
	
	
	

}
