package com.walmart.sms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.sms.entity.Student;
import com.walmart.sms.exception.StudentNotFoundException;
import com.walmart.sms.service.StudentService;

@RequestMapping("/student") //Common portion of URI for all the methods of this class

@RestController
public class StudentRestController {

	@Autowired
	private StudentService service;
	
	
	@GetMapping("/{id}")
	public ResponseEntity<Student> searchById(@PathVariable int id) throws StudentNotFoundException {
		Student searchStudent = service.searchStudent(id);
		ResponseEntity<Student> entity = new ResponseEntity<>(searchStudent,HttpStatus.OK);
		return entity;		
	}
	
	@GetMapping(params="name")
	public ResponseEntity<Student> searchByName(@RequestParam String name) {
		Student studentByName= service.findStudentByName(name);
		ResponseEntity<Student> entity = new ResponseEntity<>(studentByName,HttpStatus.OK);
		return entity;
	}
	
	
	@GetMapping
	public ResponseEntity<List<Student>> getAllStudents() {
		ResponseEntity<List<Student>> entity = new ResponseEntity<>(service.searchAll(),HttpStatus.OK);

		return entity;
	}
	
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Student> deleteStudent(@PathVariable int id) {
		this.service.deleteStudent(id);
		ResponseEntity<Student> entity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
		return entity;
	}
	
	@PostMapping
	public ResponseEntity<Student> postStudent(@RequestBody Student s) {
		ResponseEntity<Student> entity = new ResponseEntity<>(service.register(s),HttpStatus.CREATED);
		return entity;
	}
	
	@PutMapping("/{id}/{marks}")
	public void updateMarks(@PathVariable int id, @PathVariable float marks) {
		 this.service.updateMarks(id, marks);
	}
}
