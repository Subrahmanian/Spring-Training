package com.walmart.sms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmsSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
