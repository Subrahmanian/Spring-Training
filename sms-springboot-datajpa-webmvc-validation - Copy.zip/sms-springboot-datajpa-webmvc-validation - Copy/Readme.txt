REST : Representational State Transfer

1.  An architectural style if applied to web services, it becomes REST web service.
2.  Following are important guidelines for REST

--> URI must be resource based(verbs should not be written in URI)
--> Appropriate use of HTTP method 
--> Appropriate usage of HTTP status codes
--> Important HTTP status codes:

Status Code |  Explanation
200 | Success
201 | Created
204 | No-Content
404 | Not Found
401 | Unauthorized
403 | Forbidden
405 | Method not supported
500 | Internal Server Error


--> Its the responsibility of a backend developer to return appropriate status codes.
--> To do so, in Spring we use ResponseEntity class.
--> ResponseEntity class is returned by spring

*********VALIDATIONS***********

1.  Add the dependency
2.  Annotate entity fields with appropriate validation annotation
3.  annotate args of rest controller method with @Valid annotation which accesps entitty object


*****STEREOTYPE ANNOTATIONS********

1.  Are used to register classes as spring bean.  They are written on top of class definitions
2.  Following are the stereotype annotations

@Component
@Controller
@RestController
@Service
@Repository