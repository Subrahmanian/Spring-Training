package com.walmart.sms.exception;

public class StudentNotFoundException extends Exception{
	private int id;

	public StudentNotFoundException(int id) {
		super();
		this.id = id;
	}

	public int getId() {
		return id;
	}
	

}
