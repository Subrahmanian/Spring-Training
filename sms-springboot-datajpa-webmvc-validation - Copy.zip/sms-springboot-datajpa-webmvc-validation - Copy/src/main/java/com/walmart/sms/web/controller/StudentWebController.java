package com.walmart.sms.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.service.annotation.GetExchange;

//Controller returning data along with view
//This is an old style of application development
@Controller
public class StudentWebController {
	
	@GetMapping("/home")
	public String home(Model m) {
		System.out.println("In home page");
		m.addAttribute("Name","Walmart");
		return "/welcome.jsp";
		
		//Spring assumes that Welcome is a View present in the application
	}
	
	//Its used to pass the data returned from this method directly as Body of the response
	@ResponseBody
	@GetMapping("/about")
	public String aboutUs() {
		System.out.println("In About us page");
		return "About";
		//This a barebone data returned to client.
	}
	

}
