package com.walmart.sms.service;

import java.util.List;

import com.walmart.sms.entity.Student;
import com.walmart.sms.exception.StudentNotFoundException;

//Responsible for business logic.
public interface StudentService {

	public Student register(Student s) ;
	public List<Student> searchAll();
	public int deleteStudent(int rollNo);
	public Student searchStudent(int rollNo) throws StudentNotFoundException;
	public Student updateMarks(int rollNo,float marks);
	public Student findStudentByName(String name);
	
}
