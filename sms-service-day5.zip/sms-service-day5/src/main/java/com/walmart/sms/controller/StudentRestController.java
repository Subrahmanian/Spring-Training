package com.walmart.sms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.sms.entity.Student;
import com.walmart.sms.exception.StudentNotFoundException;
import com.walmart.sms.service.StudentService;
import com.walmart.sms.web.error.representation.StudentNotFoundRepresentation;

import jakarta.validation.Valid;

@RequestMapping("/student") //Common portion of URI for all the methods of this class

//Creating a rest controller which return just the data(JSON)
//RestController is a combination of controller and Response Body
@RestController
public class StudentRestController {

	@Autowired
	private StudentService service;
	
	
	@GetMapping("/{id}")
	public ResponseEntity<Student> searchById(@PathVariable int id) throws StudentNotFoundException {
		
		Student searchStudent = service.searchStudent(id);
		ResponseEntity<Student> entity = new ResponseEntity<>(searchStudent,HttpStatus.OK);
		return entity;			
	}
	
	//Whenever an exception of type StudentNotFound is thrown, from any of the methods from this class
	//Spring automatically executes following method.
	@ExceptionHandler(StudentNotFoundException.class)
	public ResponseEntity<StudentNotFoundRepresentation> handleStudentNotFoundException(StudentNotFoundException e) {
		ResponseEntity<StudentNotFoundRepresentation> entity = 
				new ResponseEntity<>(new StudentNotFoundRepresentation(HttpStatus.NOT_FOUND.value(), "Student Not Found with the ID "+e.getId() 
						),HttpStatus.NOT_FOUND);
		System.out.println("In StudentNotFound Exception block");
		return entity;
	}
	
	@GetMapping(params="name")
	public ResponseEntity<Student> searchByName(@RequestParam String name) {
		Student studentByName= service.findStudentByName(name);
		ResponseEntity<Student> entity = new ResponseEntity<>(studentByName,HttpStatus.OK);
		return entity;
	}
	
	
	@GetMapping
	public ResponseEntity<List<Student>> getAllStudents() {
		ResponseEntity<List<Student>> entity = new ResponseEntity<>(service.searchAll(),HttpStatus.OK);

		return entity;
	}
	
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Student> deleteStudent(@PathVariable int id) {
		this.service.deleteStudent(id);
		ResponseEntity<Student> entity = new ResponseEntity<>(HttpStatus.NO_CONTENT);
		return entity;
	}
	
	@PostMapping
	public ResponseEntity<Student> postStudent(@RequestBody @Valid Student s) {
		ResponseEntity<Student> entity = new ResponseEntity<>(service.register(s),HttpStatus.CREATED);
		return entity;
	}
	
	@PutMapping("/{id}/{marks}")
	public ResponseEntity<Student> updateMarks(@PathVariable int id, @PathVariable float marks) {
		ResponseEntity<Student> entity = new ResponseEntity<>(service.updateMarks(id,marks),HttpStatus.OK);
		return entity;
	}
}
