package com.walmart.sms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.walmart.sms.entity.Student;

//Responsible for interaction with database and perform CRUD operations.

public interface StudentRepository extends JpaRepository<Student, Integer>{

	//We can write custom find methods by following convention given by Data JPA as shown below.
	//1.  Method name should start with findBy followed by name of the property
	//2.  Method must accept an argument of the property type
	//3.  Method should return an object of entity type.
	
	Student findByName(String name);
		
}
