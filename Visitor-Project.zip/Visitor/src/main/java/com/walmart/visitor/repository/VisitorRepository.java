package com.walmart.visitor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.walmart.visitor.entity.Visitor;

public interface VisitorRepository extends JpaRepository<Visitor, Integer>{

	Visitor findByEmail(String email);
	List<Visitor> findByWhomToMeet(String whomToMeet);
}
