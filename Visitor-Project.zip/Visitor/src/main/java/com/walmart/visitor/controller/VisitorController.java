package com.walmart.visitor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.visitor.entity.Visitor;
import com.walmart.visitor.service.VisitorService;

@RestController
@RequestMapping("/visitor")
public class VisitorController {
	
	@Autowired
	private VisitorService service;
	
	@PostMapping
	public ResponseEntity<Visitor> createVisitor(@RequestBody Visitor v) {
		Visitor registeredVisitor = service.registerVisitor(v);
		ResponseEntity<Visitor> entity = new ResponseEntity<>(registeredVisitor,
											HttpStatus.CREATED);
		return entity;
	}
	
	
	@GetMapping
	public ResponseEntity<List<Visitor>> getAllVisitors() {
		
		List<Visitor> visitors = service.getAllVisitors();
		ResponseEntity<List<Visitor>> entity = new ResponseEntity<List<Visitor>>(visitors,HttpStatus.OK);
		return entity;
	}
	
	
	@GetMapping("/search")
	public ResponseEntity<Visitor> getEmail(@RequestParam String email) {
		
		Visitor visitorEmail = service.getByEmail(email);
		ResponseEntity<Visitor> entity = new ResponseEntity<>(visitorEmail,HttpStatus.OK);
		return entity;
	}
	
	@GetMapping("/whomtoMeet")
	public ResponseEntity<List<Visitor>> getByWhomToMeet(@RequestParam String name) {
		List<Visitor> count = service.whomToMeetFunc(name);

		ResponseEntity<List<Visitor>> response =  new ResponseEntity<List<Visitor>>(count,HttpStatus.OK);
		return response;
		
	}
	
	@GetMapping(value="/whomtoMeet",params="count")
	public ResponseEntity<Integer> getWhomToMeetCount(@RequestParam String name) {
		List<Visitor> count = service.whomToMeetFunc(name);
		ResponseEntity<Integer> respCount = new ResponseEntity<Integer>(count.size(),HttpStatus.OK);
		return respCount;
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Visitor> getById(@PathVariable int id) {
		
		Visitor visitorEmail = service.getById(id);
		ResponseEntity<Visitor> entity = new ResponseEntity<>(visitorEmail,HttpStatus.OK);
		return entity;
	}

	
	
	
	
	
	
}
