package com.walmart.visitor.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.visitor.entity.Visitor;
import com.walmart.visitor.repository.VisitorRepository;
import com.walmart.visitor.service.VisitorService;


@Service
public class VisitorServiceImpl implements VisitorService{

	@Autowired
	private VisitorRepository repo;

	
	@Override
	public List<Visitor> getAllVisitors() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Visitor registerVisitor(Visitor v) {
		// TODO Auto-generated method stub
		return repo.save(v);
	}

	@Override
	public Visitor getByEmail(String email) {
		// TODO Auto-generated method stub
		Visitor byEmail = repo.findByEmail(email);
		return byEmail;
	}

	@Override
	public List<Visitor> whomToMeetFunc(String whomToMeet) {
		// TODO Auto-generated method stub
	List<Visitor> whom = repo.findByWhomToMeet(whomToMeet); 
		return whom;
	}

	@Override
	public Visitor getById(int id) {
		return repo.findById(id).get();
	}
	
	

}
