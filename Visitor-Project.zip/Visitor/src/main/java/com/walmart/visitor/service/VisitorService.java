package com.walmart.visitor.service;

import java.util.List;

import com.walmart.visitor.entity.Visitor;

public interface VisitorService {
    public List<Visitor> getAllVisitors();
    public Visitor registerVisitor(Visitor v);
    
    public Visitor getByEmail(String email);
    
    public List<Visitor> whomToMeetFunc(String whomToMeet);
    
    public Visitor getById(int id);
}
