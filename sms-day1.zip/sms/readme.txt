Every object that spring creates is called as "Spring Bean".
Hence Spring container is also known as Bean container.
In traditional development, object creation was developer's responsibility, but in Spring its inverted to spring container.  Hence, spring container is known as IoC(Inversion of Control) container.
The process of passing Dependent to its dependencies is known as Dependency Injection(DI).
Spring was born to avoid these dependencies among multiple layers, and to make sure that layers are loosely coupled.
