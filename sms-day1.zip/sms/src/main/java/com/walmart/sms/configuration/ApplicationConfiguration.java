package com.walmart.sms.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

//To denote that this a spring configured class
@Configuration
@ComponentScan("com.walmart.sms") //Instruct spring to search for classes in this package and any of its sub-package which are annotated with service, repository, controller annotations.

public class ApplicationConfiguration {

}
