package com.walmart.sms.repository;

import org.springframework.stereotype.Repository;

import com.walmart.sms.entity.Student;

//Responsible for interaction with database and perform CRUD operations.
@Repository
public interface StudentRepository {
	public Student save(Student s);

}
