package com.walmart.sms.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.sms.entity.Student;
import com.walmart.sms.repository.StudentRepository;
import com.walmart.sms.repository.impl.StudentJPARepositoryImpl;
import com.walmart.sms.repository.impl.StudentRepositoryImpl;
import com.walmart.sms.service.StudentService;

@Service
//Each service class must be annotated with @Service, to register it as a spring bean in a spring container.
public class StudentServiceImpl implements StudentService{

	@Autowired //Its used to inject dependency(DI)
	private StudentRepository repo;
	
	public StudentServiceImpl() {
		super();		
		//repo=new StudentRepositoryImpl();//tight coupling
		//repo= new StudentJPARepositoryImpl();
	}

	@Override
	public Student register(Student s) {
		// TODO Auto-generated method stub
		System.out.println("Student Registered");
		return repo.save(s);
	}

	@Override
	public List<Student> searchAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
