package com.walmart.sms.repository.impl;

import org.springframework.stereotype.Repository;

import com.walmart.sms.entity.Student;
import com.walmart.sms.repository.StudentRepository;

@Repository
public class StudentRepositoryImpl implements StudentRepository{

	@Override
	public Student save(Student s) {
		// TODO Auto-generated method stub
		System.out.println("Inserted using old process");
		return null;
	}

}
