package com.walmart.sms.service;

import java.util.List;

import com.walmart.sms.entity.Student;

//Responsible for business logic.
public interface StudentService {

	public Student register(Student s) ;
	public List<Student> searchAll();
	
}
