package com.walmart.sms.repository.impl;

import org.springframework.stereotype.Repository;

import com.walmart.sms.entity.Student;
import com.walmart.sms.repository.StudentRepository;

//Each repository class is annotated with @Repository, which registers the class as a spring bean in spring container

//@Repository
public class StudentJPARepositoryImpl implements StudentRepository{

	@Override
	public Student save(Student s) {
		// TODO Auto-generated method stub
		System.out.println("Saved using JPA");
		return null;
	}

	
}
