package com.walmart.sms;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.walmart.sms.configuration.ApplicationConfiguration;
//To use a class outside the package, it must be imported
import com.walmart.sms.entity.Student;
import com.walmart.sms.service.StudentService;

public class StudentManagementApplication {

	public static void main(String[] args) {
		Student s;
		s=new Student(1,"Subbu",95.5f);//Object creation for student class
		
		//Create spring container object
		//This class is responsible for searching spring beans, annotated with Service, Repository, controller, component.
		
		AnnotationConfigApplicationContext container = new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
		StudentService service = container.getBean(StudentService.class);
		service.register(s);
	}

}
